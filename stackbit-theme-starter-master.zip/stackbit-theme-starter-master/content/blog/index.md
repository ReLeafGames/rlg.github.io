---
title: Blog
sections:
  - type: hero_section
    title: Blog
    align: center
  - type: blog_feed_section
    show_recent: false
layout: advanced
---
