---
title: Vos Autem Cum Perspicuis Dubia Debeatis Illustrare
date: 2020-05-30
author: data/team/dianne-ameter.yaml
categories:
  - data/categories/tutorials.yaml
  - data/categories/news.yaml
tags:
  - JAMstack
  - Sourcebit
image: images/4.png
image_alt: Post 4 placeholder image
excerpt: >-
  Itaque hoc frequenter dici solet a vobis, non intellegere nos, quam dicat Epicurus voluptatem. Sin kakan malitiam dixisses, ad aliud nos unum certum vitium consuetudo Latina traduceret.
layout: post
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Teneo, inquit, finem illi videri nihil dolere. Quid est enim aliud esse versutum. Age, inquies, ista parva sunt. Verum hoc idem saepe faciamus. Atque ab his initiis profecti omnium virtutum et originem et progressionem persecuti sunt. Duo Reges: constructio interrete. Itaque eos id agere, ut a se dolores, morbos, debilitates repellant. Estne, quaeso, inquam, sitienti in bibendo voluptas? Iam in altera philosophiae parte. Quem Tiberina descensio festo illo die tanto gaudio affecit, quanto L.

- Restinguet citius, si ardentem acceperit.
- Te enim iudicem aequum puto, modo quae dicat ille bene noris.
- Quid, quod homines infima fortuna, nulla spe rerum gerendarum, opifices denique delectantur historia?
- Quo minus animus a se ipse dissidens secumque discordans gustare partem ullam liquidae voluptatis et liberae potest.

**Quippe: habes enim a rhetoribus;** Vos autem cum perspicuis dubia debeatis illustrare, dubiis perspicua conamini tollere. Hoc dixerit potius Ennius: Nimium boni est, cui nihil est mali. Sic consequentibus vestris sublatis prima tolluntur. Negat esse eam, inquit, propter se expetendam. Ergo, si semel tristior effectus est, hilara vita amissa est.
