---
title: Gordon Norman
sections:
  - type: hero_section
    title: All Posts By Gordon Norman
    align: center
  - type: blog_feed_section
    show_recent: false
    author: data/team/gordon-norman.yaml
layout: advanced
---
