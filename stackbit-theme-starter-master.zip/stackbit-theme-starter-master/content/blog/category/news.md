---
title: News
sections:
  - type: hero_section
    title: All Posts In News
    align: center
  - type: blog_feed_section
    show_recent: false
    category: data/categories/news.yaml
layout: advanced
---
